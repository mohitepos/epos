import { useMutation } from '@tanstack/react-query';
import axios from 'axios';
import { notification } from 'antd'; // Assuming you're using Ant Design for notifications

const useAddToCart = () => {
  const mutation = useMutation({
    mutationFn: async ({ sku, qty }) => {
      const customerToken = localStorage.getItem('customerToken');
      console.log('sky,qty',sku,qty);
      
      // Log token for debugging purposes
      console.log('Customer Token:', customerToken);
      
      if (!customerToken) {
        throw new Error('Please Login. Guest Checkout is not allowed.');
      }

      try {
        
        // Send the API request to add item to the cart
        const response = await axios.post(
          '/api/rest/V1/carts/mine/items',
          {
            cartItem: {
              sku,
              qty,
            },
          },
          {
            headers: {
              Authorization: `Bearer ${customerToken}`,
              'Content-Type': 'application/json',
              },
          }
        );

        return response.data;
      } catch (error) {
        // Handle error more gracefully
        const errorMessage = error?.response?.data?.message || 'Failed to add item to cart';
        console.error(errorMessage);
        throw new Error(errorMessage);
      }
    },

    onSuccess: (data) => {
      // On success, show a notification to the user
      notification.success({
        message: 'Item Added to Cart',
        description: 'Your item has been successfully added to the cart.',
      });

      console.log('Item added to cart successfully:', data);
    },

    onError: (error) => {
      // On error, show an error notification to the user
      notification.error({
        message: 'Add to Cart Failed',
        description: error.message,
      });

      console.error('Failed to add item to cart:', error);
    },

    onSettled: () => {
      // This will run after the mutation is either successful or fails
      console.log('Mutation has settled');
    },
  });

  return mutation;
};

export default useAddToCart;
