import React from 'react'

const CustomerDashboard = () => {
  return (
    <>
      CustomerDashboard 
    </>
  )
}

export default CustomerDashboard
