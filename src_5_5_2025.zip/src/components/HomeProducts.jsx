import React, { useEffect, useState } from 'react';
import useProduct from '../hooks/useProduct';
import { Card, Row, Col, Spin, Alert, Space } from 'antd';
import { Link } from 'react-router-dom';
import { ShoppingCartOutlined } from '@ant-design/icons';
import useAddToCart from '../hooks/useAddToCart';

const { Meta } = Card;

const HomeProducts = () => {
    const { data, isError, isLoading } = useProduct();
    const [products, setProducts] = useState([]);
    const { mutate: addToCart } = useAddToCart();

    const [hoveredProductId, setHoveredProductId] = useState(null);
    const [loadingProductId, setLoadingProductId] = useState(null); // Track loading state per product

    const handleMouseEnter = (id) => setHoveredProductId(id);
    const handleMouseLeave = () => setHoveredProductId(null);

    const handleAddToCart = (product) => {
        const cartItem = {
            sku: product.sku,
            qty: 1
        };

        setLoadingProductId(product.id);
        addToCart(cartItem, {
            onSettled: () => setLoadingProductId(null),
            onSuccess: () => {
                console.log("Added to cart:", product);
            },
            onError: (error) => {
                console.error("Error adding to cart:", error);
            }
        });
    };

    useEffect(() => {
        if (data && data.items) {
            console.log("setProducts", data.items);
            setProducts(data.items);
        }
    }, [data]);

    if (isLoading) {
        return <Spin size="large" style={{ display: 'block', margin: '100px auto' }} />;
    }

    if (isError) {
        return <Alert message="Error loading products" type="error" />;
    }

    return (
        <div style={{ padding: '0 16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2>Apparel</h2>
                <a href="/apparel" style={{ color: '#041E25', fontWeight: '600', textDecoration: 'underline' }}>
                    View All
                </a>
            </div>

            <div style={{ maxWidth: '1300px', margin: '0 auto' }}>
                <Row gutter={[16, 24]} style={{ display: 'flex', flexWrap: 'wrap' }}>
                    {products.length > 0 ? (
                        products.map((product) => {
                            const productImages = product.media_gallery_entries
                                ? product.media_gallery_entries.map(entry => entry.file)
                                : [];

                            const images = productImages.map(img => `https://m2web.staging-01.eposdirect.net/media/catalog/product${img}`);

                            const specialPrice = product.custom_attributes.find(attr => attr.attribute_code === 'special_price')?.value;
                            const formattedSpecialPrice = specialPrice ? parseFloat(specialPrice).toFixed(2) : null;

                            const description = product.custom_attributes.find(attr => attr.attribute_code === 'description')?.value;
                            const productUrl = `/product/${product.id}`;

                            return (
                                <Col key={product.id} style={{ flex: '1 0 19%' }}>
                                    <Card
                                        hoverable
                                        onMouseEnter={() => handleMouseEnter(product.id)}
                                        onMouseLeave={handleMouseLeave}
                                        style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}
                                    >
                                        <Link to={`/product/${product.id}`} style={{ display: 'block' }}>
                                            <div style={{
                                                width: '100%',
                                                height: '200px',
                                                overflow: 'hidden',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            }}>
                                                <img
                                                    alt={product.name}
                                                    src={images && images.length > 0 ? images[0] : '/default.png'}
                                                    style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                                                />
                                            </div>
                                        </Link>

                                        <Meta
                                            title={
                                                <div style={{
                                                    wordWrap: 'break-word',
                                                    whiteSpace: 'normal',
                                                    color: '#041E25',
                                                    height: '48px',
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis'
                                                }}>
                                                    <a
                                                        href={productUrl}
                                                        style={{
                                                            color: hoveredProductId === product.id ? '#f6af44' : '#041E25',
                                                            textDecoration: 'none',
                                                            transition: 'color 0.3s ease',
                                                        }}
                                                    >
                                                        {product.name}
                                                    </a>
                                                </div>
                                            }
                                        />

                                        <div className="product-price" style={{ marginTop: '10px', minHeight: '40px' }}>
                                            {formattedSpecialPrice ? (
                                                <>
                                                    <strong style={{ color: '#116A83', fontWeight: 'bold' }}>
                                                        ${formattedSpecialPrice}
                                                    </strong>
                                                    <span style={{
                                                        textDecoration: 'line-through',
                                                        fontWeight: 600,
                                                        marginLeft: '10px',
                                                        color: 'gray'
                                                    }}>
                                                        ${product.price.toFixed(2)}
                                                    </span>
                                                </>
                                            ) : (
                                                <strong>${product.price}</strong>
                                            )}
                                        </div>

                                        <Row align="center" style={{ height: '32px', justifyContent: 'center', width: '100%' }}>
                                            {hoveredProductId === product.id ? (
                                                loadingProductId === product.id ? (
                                                    <Spin />
                                                ) : (
                                                    <ShoppingCartOutlined
                                                        style={{ fontSize: '24px', color: '#116A83', cursor: 'pointer' }}
                                                        onClick={() => handleAddToCart(product)}
                                                    />
                                                )
                                            ) : null}
                                        </Row>
                                    </Card>
                                </Col>
                            );
                        })
                    ) : (
                        <Col span={24}>
                            <Alert message="No products available at the moment." type="info" />
                        </Col>
                    )}
                </Row>
            </div>
        </div>
    );
};

export default HomeProducts;
